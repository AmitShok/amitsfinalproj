import React from 'react';
import Login from './features/login/Login';

function App() {

  return (
    <div>
      <Login></Login>
    </div>
  );
}

export default App;
