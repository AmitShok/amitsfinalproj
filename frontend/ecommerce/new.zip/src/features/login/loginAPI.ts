import axios from "axios";

export function userFetch(creds:any) {
    console.log(creds);
    return new Promise<{ data: any }>((resolve) =>
      axios
        .post("http://127.0.0.1:8000/" + "login", { username:creds.username, password:creds.password })
        .then((res) => resolve({ data: res.data }))
    );
  }
  