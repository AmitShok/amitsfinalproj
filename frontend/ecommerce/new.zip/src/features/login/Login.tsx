import React, { useState } from 'react'
import {loginAsync} from "../login/loginSlice"
import {useAppDispatch} from "../../app/hooks"
const Login = () => {
  const dispatch=useAppDispatch()
  const [username, setusername] = useState("")
  const [password, setpassword] = useState("")
  return (
    <div>
      Login
      <br />
      username:<input type="text" onChange={(e)=>setusername(e.target.value)} /><br />
      password<input type="text" onChange={(e)=>setpassword(e.target.value)} /><br />
<button onClick={()=>dispatch(loginAsync({username,password}))}>login</button>




    </div>
  )
}

export default Login